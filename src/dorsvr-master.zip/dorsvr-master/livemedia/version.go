package livemedia

const mediaServerVersion = "1.0.0.3"
