package livemedia

const (
	eventUnknown = 0
	eventReport  = 1
	eventBye     = 2
)

func rtcpInterval() {
}

func OnExpire(instance *RTCPInstance, members, senders uint, rtcpBW float32) {

}

func OnReceive() {
}
